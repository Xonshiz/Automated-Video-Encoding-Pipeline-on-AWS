const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();
const s3 = new AWS.S3();
var ses = new AWS.SES({
    region: process.env.Region
});
exports.handler = async (event, context) => {

    try {
        var bucket_name = event.Records[0].s3.bucket.name;
        var key_name = event.Records[0].s3.object.key;
        var search_parms = {
            TableName: process.env.DynamoDBTableName,
            Key: {
                key_name: key_name
            }
        };
        var record = await dynamo.get(search_parms).promise();
        if (record && record.Item && record.Item.user_email) {
            const url = s3.getSignedUrl('getObject', {
                Bucket: bucket_name,
                Key: key_name,
                Expires: 3600
            });
            var params = {
                Destination: {
                    ToAddresses: [record.Item.user_email],
                },
                Message: {
                    Body: {
                        Text: {
                            Data: `Hello there, your file has been encoded and is available for next 1 hour: ${url}`
                        },
                    },

                    Subject: {
                        Data: "Completed Encoding Your File"
                    },
                },
                Source: process.env.SourceEmailAddress,
            };
            ses.sendEmail(params).promise();
            return await dynamo.delete(search_parms).promise();
        }
    } catch (err) {
        console.log(`Main Exception: ${err}`);
    }
};